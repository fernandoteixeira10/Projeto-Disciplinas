/* Navegação local sem recarregar a página inteira. Funciona abrindo index.html com dois cliques. */
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const pageLabels = {
  inicio: 'Início', turnos: 'Gerenciar Turnos', areas: 'Gerenciar Áreas Acadêmicas',
  professores: 'Gerenciar Professores', cursos: 'Gerenciar Cursos', curriculos: 'Currículos',
  disciplinas: 'Gerenciar Disciplinas', 'vincular-disciplina': 'Alocar Disciplina ao Currículo',
  ingressantes: 'Turmas Ingressantes', 'gerar-ingressantes': 'Gerar Turmas Ingressantes',
  'turmas-periodo': 'Turmas em Período Letivo', 'gerar-turmas': 'Gerar Turmas em Período Letivo',
  ofertas: 'Ofertar Disciplinas', 'alocar-professor': 'Alocar Professor à Disciplina-Turma',
  cargas: 'Cargas Horárias', 'importar-exportar': 'Importação / Exportação',
  'form-turno': 'Cadastrar Turno', 'form-area': 'Cadastrar Área Acadêmica',
  'form-professor': 'Cadastrar Professor', 'form-curso': 'Cadastrar Curso',
  'form-disciplina': 'Cadastrar Disciplina', 'form-curriculo': 'Cadastrar Currículo',
  'form-ingressante': 'Cadastrar Turma Ingressante', 'form-turma': 'Cadastrar Turma'
};
const fileToKey = {
 'turnos.html':'turnos','areas-academicas.html':'areas','professores.html':'professores','cursos.html':'cursos',
 'curriculos.html':'curriculos','disciplinas.html':'disciplinas','alocar-disciplina-curriculo.html':'vincular-disciplina',
 'turmas-ingressantes.html':'ingressantes','gerar-turmas-ingressantes.html':'gerar-ingressantes',
 'turmas-periodo-letivo.html':'turmas-periodo','gerar-turmas-periodo-letivo.html':'gerar-turmas',
 'ofertas-disciplinas.html':'ofertas','alocar-professor.html':'alocar-professor','cargas-horarias.html':'cargas',
 'importar-exportar.html':'importar-exportar','form-turno.html':'form-turno','form-area-academica.html':'form-area',
 'form-professor.html':'form-professor','form-area-academica.html':'form-area','form-curso.html':'form-curso','form-disciplina.html':'form-disciplina',
 'form-curriculo.html':'form-curriculo','form-ingressante.html':'form-ingressante','form-turma.html':'form-turma'
};
function showToast(message) {
  let toast = $('#toast');
  if (!toast) { toast=document.createElement('div'); toast.id='toast'; toast.className='toast'; toast.setAttribute('role','status'); document.body.appendChild(toast); }
  toast.textContent=message; toast.classList.add('show'); clearTimeout(window.toastTimer);
  window.toastTimer=setTimeout(()=>toast.classList.remove('show'),3000);
}
function currentPage(){ return document.body.dataset.pageKey || 'inicio'; }
function renderPage(target) {
  const template=$('#view-'+target);
  if (!template) return;
  const content=$('#page-content');
  content.replaceChildren(template.content.cloneNode(true));
  document.body.dataset.pageKey=target;
  const breadcrumb=$('#breadcrumb');
  if (breadcrumb) breadcrumb.innerHTML='<span>⌂</span><span>›</span><span>'+ (pageLabels[target] || target) +'</span>';
  $$('#main-nav [data-page]').forEach(item=>item.classList.toggle('active',item.dataset.page===target));
  // Mantém aberto o grupo do menu que contém a tela selecionada.
  const active=$('#main-nav .nav-item.active');
  const group=active?.closest('.nav-children');
  $$('.nav-children').forEach(children=>{ if(children!==group && !children.dataset.keepOpen) children.classList.add('hidden'); });
  if(group) group.classList.remove('hidden');
  $('#sidebar')?.classList.remove('open');
  bindPageEvents();
  window.scrollTo(0,0);
}
function goTo(target){ if(target) renderPage(target); }
function exportDemoData() {
  const data={cursos:[['TEC-INFO','Técnico em Informática','EMI'],['ADS','Análise e Desenvolvimento de Sistemas','GRA']],professores:[['Ana','Souza Silva','A. Souza','ana.souza@ifrs.edu.br'],['Carlos','Eduardo Lima','C. Lima','carlos.lima@ifrs.edu.br']],disciplinas:[['INF101','Programação I',4,80],['MAT101','Matemática I',4,80]],turnos:[['M','Matutino'],['T','Vespertino'],['N','Noturno']]};
  const format=$('#export-format')?.value||'json'; let contents,mime,filename;
  if(format==='csv'){contents='entidade,campo1,campo2,campo3\n'+Object.entries(data).flatMap(([entity,rows])=>rows.map(row=>[entity,...row.slice(0,3)].map(value=>'"'+String(value).replaceAll('"','""')+'"').join(','))).join('\n');mime='text/csv';filename='dados-demonstrativos.csv';}
  else {contents=JSON.stringify(data,null,2);mime='application/json';filename='dados-demonstrativos.json';}
  const url=URL.createObjectURL(new Blob([contents],{type:mime}));const a=document.createElement('a');a.href=url;a.download=filename;a.click();URL.revokeObjectURL(url);showToast('Arquivo demonstrativo exportado.');
}
function bindPageEvents(){
  $$('.data-form').forEach(form=>{ if(form.dataset.bound) return; form.dataset.bound='1'; form.addEventListener('submit',event=>{event.preventDefault();showToast('Formulário validado no protótipo. A gravação será conectada ao IndexedDB.');form.reset();}); });
  $('#table-filter')?.addEventListener('input',event=>{const term=event.target.value.toLowerCase();$$('#table-holder tbody tr').forEach(row=>row.style.display=row.innerText.toLowerCase().includes(term)?'':'none');});
}
document.addEventListener('click',event=>{
  const nav=event.target.closest('[data-href]');
  if(nav){event.preventDefault();let target=nav.dataset.go||nav.dataset.page; if(!target){const file=(nav.dataset.href||'').split('/').pop();target=file==='index.html'?'inicio':fileToKey[file];}if(target)goTo(target);return;}
  const go=event.target.closest('[data-go]');if(go){event.preventDefault();goTo(go.dataset.go);return;}
  const group=event.target.closest('[data-group]');if(group){const children=$(`[data-children="${group.dataset.group}"]`);if(children){children.classList.toggle('hidden');const arrow=group.querySelector('b');if(arrow)arrow.textContent=children.classList.contains('hidden')?'⌄':'⌃';}return;}
  const action=event.target.closest('[data-action]')?.dataset.action;
  if(action==='demo-generate')showToast('Ação demonstrativa. A geração será conectada às regras e à base de dados.');
  if(action==='filter-report')showToast('Filtros aplicados à visualização demonstrativa.');
  if(action==='import-file')$('#import-file')?.click();
  if(action==='export-data')exportDemoData();
  if(action==='delete')showToast('A remoção será conectada à base de dados.');
  if(action==='edit')showToast('A edição será habilitada na integração dos dados.');
});
$('#mobile-menu')?.addEventListener('click',()=>$('#sidebar')?.classList.toggle('open'));
$('#search-btn')?.addEventListener('click',()=>{const query=($('#global-search')?.value||'').toLowerCase().trim();if(!query)return;const found=Object.entries(pageLabels).find(([,label])=>label.toLowerCase().includes(query));if(found)goTo(found[0]);else showToast('Nenhuma tela encontrada com esse termo.');});
$('#global-search')?.addEventListener('keydown',event=>{if(event.key==='Enter')$('#search-btn')?.click();});
bindPageEvents();
